import astextractor.ASTExtractor;

/**
 * Created by qiaoyang on 17-5-6.
 */
public class Test {
    public static void main(String[] args) {
        String path = "/home/qiaoyang/codeData/demo.java";//"/home/qiaoyang/javaProject/JavaAnalyse/src/main/resources/a.java"
        String ast = ASTExtractor.parseFile(path);
        System.out.println(ast);
    }
}
